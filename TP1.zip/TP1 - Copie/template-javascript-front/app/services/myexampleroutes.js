import ListAPI from "./listAPI.js";
export default class MyExampleRoutes extends ListAPI {
    constructor() {
        super();
        this.routesUrl = "/List"
    }

    getSomething() {
        return this.fetchList(`${this.routesUrl}`)
    }

}