export default class ListAPI {
    constructor() {
        this.apiServer = "http://localhost:3333"
    }

    fetchList(routesURL) {
        return new Promise(((resolve, reject) => {
            fetch(`${this.apiServer}${routesURL}`)
                .then(response => {
                    if (response.status === 200) {
                        resolve(response.json())
                    } else {
                        reject(response.status)
                    }
                })
                .catch(err => reject(err))
        }))
    }

    getAll() {
        return fetchJSON(`${this.apiServer}/List`)
    }
    get(id) {
        return fetchJSON(`${this.apiServer}/List/${id}`)
    }
    delete(id) {
        return fetch(`${this.apiServer}/List/${id}`, { method: 'DELETE' })
    }
    insert(list) {
        return fetch(`${this.apiServer}/List`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(list)
        })
    }
    update(list) {
        return fetch(`${this.apiServer}/List/${list.id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(list)
        })
    }
}