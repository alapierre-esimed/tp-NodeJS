import Model from "../model/model.js";
export default class BaseController {
    constructor() {
        this.setBackButtonView('index')
        this.model = new Model()
    }
    setBackButtonView(view) {
        window.onpopstate = function() {
            navigate(view)
        }; history.pushState({}, '');
    }
}