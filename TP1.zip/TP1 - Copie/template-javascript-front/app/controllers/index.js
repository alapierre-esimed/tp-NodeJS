import BaseController from "./basecontroller.js";
export default class IndexController extends BaseController {
    constructor() {
        super()
        this.tableAllLists = document.getElementById('tableAllLists');
        this.tableBodyAllLists = this.tableAllLists.getElementsByTagName('tbody')[0];
        this.displayAllLists()
    }
    async displayAllLists() {
        let content = ''
        this.tableAllLists.style.display = "none"
        try {
            const lists = await this.model.getAllLists();
            for (const list of lists) {
                const date = new Date(list.date).toLocaleDateString();
                content += `<tr><td>${list.id}</td>
                    <td>${list.shop}</td>  
                    <td>${date}</td>
                    <td>${list.archived}</td>
                    <td class="icon">
                    <button class="btn" onclick="indexController.displayConfirmDelete(${list.id})"><i class="material-icons">delete</i></button>
                    <button class="btn" onclick="indexController.edit(${list.id})"><i class="material-icons">edit</i></button>
                    </td></tr>`
            }
            this.tableBodyAllLists.innerHTML = content
            this.tableAllLists.style.display = "block"
        } catch (err) {
            console.log(err)
        }
    }
    async edit(id) {
        try {
            const object = await this.model.getList(id)
            if (object === undefined) {
                this.displayServiceError()
                return
            }
            if (object === null) {
                this.displayNotFoundError()
                return
            }
            this.selectedList = object
            navigate("edit")
        } catch (err) {
            console.log(err)
            this.displayServiceError()
        }
    }
    undoDelete() {
        if (this.deletedList) {
            this.model.insert(this.deletedList).then(status => {
                if (status === 200) {
                    this.deletedList = null
                    this.displayUndoDone()
                    this.displayAllLists()
                }
            }).catch(_ => this.displayServiceError())
        }
    }
    async displayConfirmDelete(id) {
        try {
            const list = await this.model.getList(id)
            super.displayConfirmDelete(list, async () => {
                switch (await this.model.delete(id)) {
                    case 200:
                        break
                    case 404:
                        this.displayNotFoundError();
                        break
                    default:
                        this.displayServiceError()
                }
                this.displayAllLists()
            })
        } catch (err) {
            console.log(err)
            this.displayServiceError()
        }
    }
}

window.indexController = new IndexController()