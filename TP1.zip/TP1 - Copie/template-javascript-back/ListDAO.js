const dao = require('./dao')

module.exports = class ListDAO extends dao{
    constructor(db) {
        super(db,"List")
    }
    delete(id) {
        return this.db.query(`DELETE FROM ${this.tablename} WHERE id=$1`, [id])
    }
    getById(id) {
        return new Promise((resolve, reject) =>
            this.db.query(`SELECT * FROM List WHERE id=$1`, [ id ])
                .then(res => resolve(res.rows[0]) )
                .catch(e => reject(e)))
    }

    getAll(){
        return new Promise((resolve, reject) =>
            this.db.query(`SELECT * FROM List`)
                .then(res => resolve(res.rows) )
                .catch(e => reject(e)))
    }

    insert(list) {
        return this.db.query("INSERT INTO list(shop,date,archived) VALUES ($1,$2,$3)",
            [list.shop, list.date, list.archived])
    }

    update(list) {
        return this.db.query("UPDATE list SET shop=$2,date=$3,archived=$4 WHERE id=$1",
            [list.id, list.shop, list.date, list.archived])
    }
}