module.exports = class Item{
    constructor(label, quantity, checked) {
        this.label = label
        this.quantity = quantity
        this.checked = checked
    }
}