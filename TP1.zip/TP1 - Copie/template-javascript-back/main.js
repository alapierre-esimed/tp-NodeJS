const pg = require('pg')
const express = require('express')
const bodyParser = require('body-parser')
const cors = require('cors')
const morgan = require('morgan')
const item = require('./item');
const list = require('./list')

const listServices = require("./ListServices")
const itemServices = require("./ItemServices")

const app = express()
app.use(bodyParser.urlencoded({ extended: false })) // URLEncoded form data
app.use(bodyParser.json()) // application/json
app.use(cors())
app.use(morgan('dev'));

const connectionString = "postgres://user:password@localhost/NodeJS"
const db = new pg.Pool({ connectionString: connectionString })
const listService = new listServices(db)
const itemService = new itemServices(db)
require('./api/ListAPI')(app, listService)
require('./api/ItemAPI')(app, itemService)
require('./datamodel/seeder')(itemService, listService)
    .then(app.listen(3333))


