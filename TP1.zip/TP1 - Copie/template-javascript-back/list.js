module.exports = class List{
    constructor(shop, date, archived) {
        this.shop = shop
        this.date = date
        this.archived = archived
    }
}