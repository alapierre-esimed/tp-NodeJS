const Item = require('../item')
const List = require('../list')

module.exports = (itemService, listService) => {
    return new Promise(async (resolve, reject) => {
        try {
            await itemService.dao.db.query("CREATE TABLE item(id SERIAL PRIMARY KEY, label TEXT, quantity INT, checked BOOLEAN )")
            for (let i = 0; i < 5; i++) {
                await itemService.dao.insert(new Item("shop" + i, Math.floor(Math.random() * 30000), true))
            }
            await listService.dao.db.query("CREATE TABLE list(id SERIAL PRIMARY KEY, shop TEXT, date DATE, archived BOOLEAN)")
            for (let i = 0; i < 5; i++) {
                await listService.dao.insert(new List("test", new Date(+(new Date()) - Math.floor(Math.random() * 10000000000)), true))
            }
            resolve()
        } catch (e) {
            if (e.code === "42P07") { // TABLE ALREADY EXISTS https://www.postgresql.org/docs/8.2/errcodes-appendix.html
                resolve()
            } else {
                reject(e)
            }
        }
    })
}