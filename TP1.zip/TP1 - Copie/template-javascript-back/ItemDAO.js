const dao = require('./dao')

module.exports = class ItemDAO extends dao{
    constructor(db) {
        super(db,"Item")
    }
    delete(id) {
        return this.db.query(`DELETE FROM ${this.tablename} WHERE id=$1`, [id])
    }
    getById(id) {
        return new Promise((resolve, reject) =>
            this.db.query(`SELECT * FROM ${this.tablename} WHERE id=$1`, [ id ])
                .then(res => resolve(res.rows[0]) )
                .catch(e => reject(e)))
    }

    insert(item) {
        return this.db.query("INSERT INTO item(label,quantity,checked) VALUES ($1,$2,$3)",
            [item.label, item.quantity, item.checked])
    }

    update(item) {
        return this.db.query("UPDATE item SET label=$2,quantity=$3,checked=$4 WHERE id=$1",
            [item.id, item.label, item.quantity, item.checked])
    }
    getAll(){
        return new Promise((resolve, reject) =>
            this.db.query(`SELECT * FROM ${this.tablename}`)
                .then(res => resolve(res.rows[0]) )
                .catch(e => reject(e)))
    }
}